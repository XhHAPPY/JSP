package Servlet;
import util.userDmlDao;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class userServlet /*extends BaseServlet*/ {
//	private ApplicantService applicantService=new ApplicantServiceImpl();
//	private PositionService positionService=new PositionServiceImpl();
//	private AdminService adminService=new AdminServiceImpl();

	public String toAddPage(HttpServletRequest request, HttpServletResponse response) throws Exception	{
		response.setContentType("text/html;charset=utf-8");
		userDmlDao dao=new userDmlDao();
		List positionList=dao.findALLuser();
		request.setAttribute("positionList", positionList);
		request.getRequestDispatcher("/addapplicant").include(request, response);
		return null;
	}

//	public String applicantAdd(HttpServletRequest request, HttpServletResponse response) throws Exception{
//		Applicant applicant = new Applicant();
//		applicant.setName(request.getParameter("name"));
//		applicant.setSex(new Byte(request.getParameter("sex")));
//		applicant.setAge(Integer.valueOf(request.getParameter("age")));
//		applicant.setJob(request.getParameter("job"));
//		applicant.setSpecialty(request.getParameter("specialty"));
//		applicant.setSchool(request.getParameter("school"));
//		applicant.setExperience(request.getParameter("experience"));
//		applicant.setStudyeffort(request.getParameter("studyeffort"));
//		applicant.setTel(request.getParameter("tel"));
//		applicant.setEmail(request.getParameter("email"));
//		applicant.setCreatetime(new java.util.Date());
//	    applicant.setContent(request.getParameter("content"));
//	    applicant.setIsstock(new Byte("0"));
//	    applicantService.saveApplicant(applicant);
//		response.setCharacterEncoding("UTF-8");
////		response.setContentType("text/html;charset=utf-8");
//		request.getRequestDispatcher("./public/alert.jsp").include(request, response);
//        PrintWriter out = response.getWriter();
//        //跳转到列表页面
//        out.println("<script>ok_alert(\"添加成功\",\"main.jsp?method=findApplicantByIsstock&isstock=0&servlet=ApplicantServlet\");</script>");
//		return null;
//	}
//
//	public List applicantList(HttpServletRequest request, HttpServletResponse response) throws Exception{
//		List applicantList=applicantService.findApplicantByIsstock("0");
//		request.setAttribute("applicantList", applicantList);
//		List positionList=positionService.findAllPosition();
//		request.setAttribute("positionList", positionList);
//		request.getRequestDispatcher("/admin/listapplicant.jsp").include(request, response);
//		return null;
//	}
//	public List applicantDetail(HttpServletRequest request, HttpServletResponse response) throws Exception{
//		String  id = request.getParameter("id");
//		String isstock = request.getParameter("isstock");
//		response.setContentType("text/html;charset=utf-8");
//		Applicant applicant = applicantService.findApplicantById(id);
//		request.setAttribute("applicant", applicant);
//		if(isstock.equals("3") && isstock!=null) {
//			Admin adminuser =adminService.findUserById(applicant.getAdmin().toString() );
//			request.setAttribute("admin", adminuser);
//		}
//		List positionList=positionService.findAllPosition();
//		request.setAttribute("positionList", positionList);
//		request.getRequestDispatcher("/admin/detailapplicant.jsp").include(request, response);
//		return null;
//	}
//	public String applicantDelete(HttpServletRequest request, HttpServletResponse response) throws Exception{
//		String id = request.getParameter("id");
//		Applicant applicant = applicantService.findApplicantById(id);
//		applicantService.deleteApplicant(id);
//		response.setContentType("text/html;charset=utf-8");
//		request.getRequestDispatcher("./public/alert.jsp").include(request, response);
//        PrintWriter out = response.getWriter();
//        //跳转到列表页面
//        out.println("<script>ok_alert(\"删除成功\",\"main.jsp?method=findApplicantByIsstock&isstock=0&servlet=ApplicantServlet\");</script>");
//		return null;
//	}
//
//	public String updateToApplicant(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
//		Applicant applicant = new Applicant();
//		applicant.setName(request.getParameter("name"));
//		applicant.setSex(new Byte(request.getParameter("sex")));
//		applicant.setAge(Integer.valueOf(request.getParameter("age")));
//		applicant.setJob(request.getParameter("job"));
//		applicant.setSpecialty(request.getParameter("specialty"));
//		applicant.setSchool(request.getParameter("school"));
//		applicant.setExperience(request.getParameter("experience"));
//		applicant.setStudyeffort(request.getParameter("studyeffort"));
//		applicant.setTel(request.getParameter("tel"));
//		applicant.setEmail(request.getParameter("email"));
//		applicantService.updateApplicant1(applicant);
////		applicantService.updateApplicant1(applicant);
//		response.setContentType("text/html;charset=utf-8");
//		request.getRequestDispatcher("./public/alert.jsp").include(request, response);
//		PrintWriter out = response.getWriter();
//		out.println("<script>ok_alert(\"修改成功!\",\"main.jsp?method=listPosition&servlet=PositionServlet\");</script>");
//		return null;
//	}
//
////刷新
//	public String applicantUpdate(HttpServletRequest request, HttpServletResponse response) throws Exception{
//		String id = request.getParameter("id");
//		applicantService.updateApplicant(id);
//		List applicantList=applicantService.findApplicantByIsstock("1");
//		request.setAttribute("applicantList", applicantList);
//		request.getRequestDispatcher("/admin/listapplicant.jsp").include(request, response);
//		return null;
//	}
//
//	//找到入库人员
//	public String findApplicantByIsstock(HttpServletRequest request, HttpServletResponse response) throws Exception{
//		String isstock = request.getParameter("isstock");
//		List positionList=positionService.findAllPosition();
//		request.setAttribute("positionList", positionList);
//		List applicantList=applicantService.findApplicantByIsstock(isstock);
//		request.setAttribute("applicantList", applicantList);
//
//		request.getRequestDispatcher("/admin/listapplicant.jsp").include(request, response);
//		return null;
//	}
//
//	public String applicantemployment(HttpServletRequest request, HttpServletResponse response) throws Exception {
//
//
//		return null;
//
//	}
}