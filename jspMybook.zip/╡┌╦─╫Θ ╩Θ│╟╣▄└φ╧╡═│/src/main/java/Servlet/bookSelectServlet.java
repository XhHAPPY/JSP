package Servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import domain.Book;
import util.userDmlDao;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @xh
 */
public class bookSelectServlet {
        public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            doPost(request, response);
        }

        public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            //处理中文乱码问题
            response.setContentType("text/html;charset=utf-8");
            request.setCharacterEncoding("utf-8");
            PrintWriter out = response.getWriter();

            userDmlDao userDao = new userDmlDao();
            ArrayList bookslist = new ArrayList<Book>();
            try {
                bookslist=  userDao.findALLuser();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            // 将List转换成JSON字符串
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(bookslist);
            response.setContentType("text/json;charset=utf-8");
            System.out.println(json);
            out.print(json);
            out.flush();
            out.close();

//        String json=JSON.toJSON(bookslist).toString();
//        response.setContentType("text/json;charset=utf-8");
//        String json2 = JSON.toJSONString(bookslist);

        }
}
