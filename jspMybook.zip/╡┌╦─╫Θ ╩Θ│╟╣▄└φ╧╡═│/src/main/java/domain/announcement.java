package domain;

import java.sql.Time;
import java.util.Date;

/**
 * @xh
 *  公告表
 * 编号、标题、公告内容、发布日期
 */
public class announcement {
    private int anid;
    private String antitle;
    private String andetail;
    private Date datetime;
//    private  String datetime;

    public int getAnid() {
        return anid;
    }

    public void setAnid(int anid) {
        this.anid = anid;
    }

    public String getAntitle() {
        return antitle;
    }

    public void setAntitle(String antitle) {
        this.antitle = antitle;
    }

    public String getAndetail() {
        return andetail;
    }

    public void setAndetail(String andetail) {
        this.andetail = andetail;
    }

    public Date getDatetime() {
        return datetime;
    }

    public void setDatetime(Time datetime) {
        this.datetime = datetime;
    }
//    public String getDatetime() {
//        return datetime;
//    }
//
//    public void setDatetime(String datetime) {
//        this.datetime = datetime;
//    }
}
