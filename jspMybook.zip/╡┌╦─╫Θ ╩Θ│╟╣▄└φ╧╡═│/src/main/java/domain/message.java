package domain;

/**
 * @xh
 * 读者留言信息
 * user插入
 * admin查看
 * 编号、借阅证编号、留言内容、留言日期
 */
public class message {
    private int id;
    private int userid;
    private String message;
    private  String date;
  private  String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
