package domain;

/**
 * @xh
 * 借书规则表
 *  编号、限制借阅数量、限制借阅天数、图书超期每天费用
 */
public class borrow_rules {
    private int id;
    private int borrow_num;
    private int limit_day;
    private float overfee;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBorrow_num() {
        return borrow_num;
    }

    public void setBorrow_num(int borrow_num) {
        this.borrow_num = borrow_num;
    }

    public int getLimit_day() {
        return limit_day;
    }

    public void setLimit_day(int limit_day) {
        this.limit_day = limit_day;
    }

    public float getOverfee() {
        return overfee;
    }

    public void setOverfee(float overfee) {
        this.overfee = overfee;
    }
}
