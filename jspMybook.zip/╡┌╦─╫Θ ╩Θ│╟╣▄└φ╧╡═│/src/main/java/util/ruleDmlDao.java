package util;//package Dao;

import domain.Admin;
import domain.User;
import domain.borrow_rules;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @xh
 */
public class ruleDmlDao {
    Connection con=null;
    PreparedStatement prem=null;
    ResultSet rs=null;
    ArrayList list=new ArrayList();//存储rs结果集
    int i=0;

    public int insert(int id,int num,int day,float fee) throws SQLException, ClassNotFoundException {
        con=BaseDao.getConnection();//获取连接
        String sql = "insert into borrow_rules (id,borrow_num,limit_day,overfee) values(?,?,?,?)";
        prem=con.prepareStatement(sql);//执行sql
        prem.setInt(1,id);
        prem.setInt(2,num);//第一个参数
        prem.setInt(3,day);//第二个参数
        prem.setFloat(4,fee);
        i=prem.executeUpdate();
        BaseDao.close(null,prem,con);
        return i;
    }
    public  int delete(int id) throws SQLException {
        String sql="delete from borrow_rules where id=?";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            prem.setInt(1,id);
            i=prem.executeUpdate();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally{
            BaseDao.close(null,prem,con);
        }
        return i;
    }

    public int update(int id,int num,int day,float fee) throws SQLException {
        String sql="update borrow_rules set borrow_num=?,limit_day=?,overfee=? where id=?";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            prem.setInt(1,num);
            prem.setInt(2,day);
            prem.setFloat(3,fee);
            prem.setInt(4,id);
            i=prem.executeUpdate();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.close(null,prem,con);
        }
        return i ;
    }

    public ArrayList findALL() throws SQLException {
        String sql="select * from borrow_rules";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            rs=prem.executeQuery();
            while (rs.next()){
                borrow_rules t=new borrow_rules();
                t.setId(rs.getInt(1));
                t.setBorrow_num(rs.getInt(2));
                t.setLimit_day(rs.getInt(3));
                t.setOverfee(rs.getInt(4));
                list.add(t);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.close(rs,prem,con);
        }
        return list;
    }
//   public ArrayList mohuFind() throws SQLException, ClassNotFoundException {
//        String sql="select * from test where name like h%";
//        con=BaseDao.getConnection();
//        prem=con.prepareStatement(sql);
//        rs=prem.executeQuery();
//        while(rs.next()){
//            Test t=new Test();
//            t.setId(rs.getInt(1));
//            t.setName(rs.getString(2));
//            t.setAge(rs.getInt(3));
//            list.add(t);
//        }
//       BaseDao.close(rs,prem,con);
//        return list;
//   }
}
