package util;

import java.sql.*;

/**
 * @xh
 */
public class BaseDao {
    //建立数据库连接方法
    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");//注册驱动

        String url="jdbc:mysql://localhost:3306/jspdesign";
        final String name="root";
        final String pwd="123456";
        return   DriverManager.getConnection(url,name,pwd);//建立连接
    }
    public static void close(ResultSet rs,Statement sta,Connection con) throws SQLException {
        if(rs!=null){rs.close();}
        if(sta!=null){sta.close();}
        if(con!=null){con.close();}
    }
}
