package util;//package Dao;

import domain.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @xh
 */
public class userDmlDao {
    Connection con=null;
    PreparedStatement prem=null;
    ResultSet rs=null;
    ArrayList list=new ArrayList();//存储rs结果集
    int i=0;

    public int insert(int id,String name,int age) throws SQLException, ClassNotFoundException {
        con=BaseDao.getConnection();//获取连接
        String sql = "insert into test (id,name,age) values(?,?,?)";
        prem=con.prepareStatement(sql);//执行sql
        prem.setInt(1,id);
        prem.setString(2,name);//第一个参数
        prem.setInt(3,age);//第二个参数
        i=prem.executeUpdate();
        BaseDao.close(null,prem,con);
        return i;
    }
    public  int delete(int id) throws SQLException {
        String sql="delete from user where userid=?";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            prem.setInt(1,id);
            i=prem.executeUpdate();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally{
            BaseDao.close(null,prem,con);
        }
      return i;
    }

    public int adminupdate(int id,String name,String pwd,String status) throws SQLException {
        String sql="update user set username=?,userpwd=?,cord=? where userid=?";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            prem.setInt(1,id);
            prem.setString(1,name);
            prem.setString(2,pwd);
            prem.setString(3,status);
            i=prem.executeUpdate();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.close(null,prem,con);
        }
        return i ;
    }
    public int update(String name,String pwd,String status) throws SQLException {
       String sql="update user set userpwd=?,cord=? where username=?";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            prem.setString(1,pwd);
            prem.setString(2,status);
            prem.setString(3,name);
            i=prem.executeUpdate();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.close(null,prem,con);
        }
        return i ;
    }

    public ArrayList findALLuser() throws SQLException {
        String sql="select * from user";
        try {
            con=BaseDao.getConnection();
            prem=con.prepareStatement(sql);
            rs=prem.executeQuery();
            while (rs.next()){
                User t=new User();
                t.setUserid(rs.getInt(1));
                t.setUsername(rs.getString(2));
                t.setUserpwd(rs.getString(3));
                t.setStatus(rs.getString(4));
                list.add(t);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            BaseDao.close(rs,prem,con);
        }
        return list;
    }
   public ArrayList mohuFind(String name) throws SQLException, ClassNotFoundException {
        String sql="select * from user where name=?";
        con=BaseDao.getConnection();
        prem=con.prepareStatement(sql);
        prem.setString(1,name);
        rs=prem.executeQuery();
        //查询数据库表
        while(rs.next()){
            User t=new User();
            t.setUserid(rs.getInt(1));
            t.setUsername(rs.getString(2));
            t.setUserpwd(rs.getString(3));
            t.setStatus(rs.getString(4));
            list.add(t);
        }
       BaseDao.close(rs,prem,con);
        return list;
   }
}
