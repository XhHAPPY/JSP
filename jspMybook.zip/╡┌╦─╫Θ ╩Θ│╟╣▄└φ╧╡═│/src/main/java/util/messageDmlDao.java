package util;

import domain.Admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @xh
 */
public class messageDmlDao {
        Connection con=null;
        PreparedStatement prem=null;
        ResultSet rs=null;
        ArrayList list=new ArrayList();//存储rs结果集
        int i=0;

        public int insert(int id,String name,String mes) throws SQLException, ClassNotFoundException {
            con=BaseDao.getConnection();//获取连接
            String sql = "insert into message (userid,username,message) values(?,?,?)";
            prem=con.prepareStatement(sql);//执行sql
            prem.setInt(1,id);
            prem.setString(2,name);//第一个参数
            prem.setString(3,mes);//第二个参数
            i=prem.executeUpdate();
            BaseDao.close(null,prem,con);
            return i;
        }
        public  int delete(int id) throws SQLException {
            String sql="delete from test where id=?";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                prem.setInt(1,id);
                i=prem.executeUpdate();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally{
                BaseDao.close(null,prem,con);
            }
            return i;
        }

        public int update(int id,String name,String pwd,String email) throws SQLException {
            String sql="update admin set adminname=?,adminpwd=?,email=? where adminid=?";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                prem.setString(1,name);
                prem.setString(2,pwd);
                prem.setString(3,email);
                prem.setInt(4,id);
                i=prem.executeUpdate();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally {
                BaseDao.close(null,prem,con);
            }
            return i ;
        }

        public ArrayList findALL() throws SQLException {
            String sql="select * from admin";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                rs=prem.executeQuery();
                while (rs.next()){
                    Admin t=new Admin();
                    t.setAdminid(rs.getInt(1));
                    t.setAdminname(rs.getString(2));
                    t.setAdminpwd(rs.getString(3));
                    t.setEmail(rs.getString(4));
                    list.add(t);
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally {
                BaseDao.close(rs,prem,con);
            }
            return list;
        }
//   public ArrayList mohuFind() throws SQLException, ClassNotFoundException {
//        String sql="select * from test where name like h%";
//        con=BaseDao.getConnection();
//        prem=con.prepareStatement(sql);
//        rs=prem.executeQuery();
//        while(rs.next()){
//            Test t=new Test();
//            t.setId(rs.getInt(1));
//            t.setName(rs.getString(2));
//            t.setAge(rs.getInt(3));
//            list.add(t);
//        }
//       BaseDao.close(rs,prem,con);
//        return list;
//   }
    }


