package util;

import domain.Admin;
import domain.userborrow_card;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @xh
 */
public class borrowCardDmlDao {

        Connection con=null;
        PreparedStatement prem=null;
        ResultSet rs=null;
        ArrayList list=new ArrayList();//存储rs结果集
        int i=0;

        public int insert(int id,String name,String pwd,String email) throws SQLException, ClassNotFoundException {
            con=BaseDao.getConnection();//获取连接
            String sql = "insert into admin (adminid,adminname,adminpwd,email) values(?,?,?,?)";
            prem=con.prepareStatement(sql);//执行sql
            prem.setInt(1,id);
            prem.setString(2,name);//第一个参数
            prem.setString(3,pwd);//第二个参数
            prem.setString(3,email);//第二个参数
            i=prem.executeUpdate();
            BaseDao.close(null,prem,con);
            return i;
        }

        public  int delete(int id) throws SQLException {
            String sql="delete from test where id=?";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                prem.setInt(1,id);
                i=prem.executeUpdate();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally{
                BaseDao.close(null,prem,con);
            }
            return i;
        }

        public int update(int id,String name,String pwd,String email) throws SQLException {
            String sql="update admin set adminname=?,adminpwd=?,email=? where adminid=?";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                prem.setString(1,name);
                prem.setString(2,pwd);
                prem.setString(3,email);
                prem.setInt(4,id);
                i=prem.executeUpdate();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally {
                BaseDao.close(null,prem,con);
            }
            return i ;
        }

        public ArrayList findALL() throws SQLException {
            String sql="select * from admin";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                rs=prem.executeQuery();
                while (rs.next()){
                    Admin t=new Admin();
                    t.setAdminid(rs.getInt(1));
                    t.setAdminname(rs.getString(2));
                    t.setAdminpwd(rs.getString(3));
                    t.setEmail(rs.getString(4));
                    list.add(t);
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally {
                BaseDao.close(rs,prem,con);
            }
            return list;
        }
   public ArrayList mohuFind(String name) throws SQLException, ClassNotFoundException {
        String sql="select * from userborrow_card where card_user=?";
        con=BaseDao.getConnection();
        prem=con.prepareStatement(sql);
        prem.setString(1,name);
        rs=prem.executeQuery();
        while(rs.next()){
//            创建对象
            userborrow_card t=new userborrow_card();
            t.setCard_user(rs.getString(1));
            t.setBorrow_num(rs.getInt(2));
            t.setBook_name(rs.getString(3));
            t.setBorrow_time(rs.getTime(4));
            t.setEnd_time(rs.getTime(5));
            t.setReturn_time(rs.getTime(6));
            list.add(t);
        }
       BaseDao.close(rs,prem,con);
        return list;
   }


}
