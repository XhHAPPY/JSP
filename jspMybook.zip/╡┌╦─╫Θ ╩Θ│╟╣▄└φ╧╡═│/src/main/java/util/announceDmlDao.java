package util;

import domain.Admin;
import domain.announcement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @xh
 */
public class announceDmlDao {
        Connection con=null;
        PreparedStatement prem=null;
        ResultSet rs=null;
        ArrayList list=new ArrayList();//存储rs结果集
        int i=0;

        public int insert(int id,String name,int age) throws SQLException, ClassNotFoundException {
            con=BaseDao.getConnection();//获取连接
            String sql = "insert into test (id,name,age) values(?,?,?)";
            prem=con.prepareStatement(sql);//执行sql
            prem.setInt(1,id);
            prem.setString(2,name);//第一个参数
            prem.setInt(3,age);//第二个参数
            i=prem.executeUpdate();
            BaseDao.close(null,prem,con);
            return i;
        }
        public  int delete(int id) throws SQLException {
            String sql="delete from test where id=?";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                prem.setInt(1,id);
                i=prem.executeUpdate();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally{
                BaseDao.close(null,prem,con);
            }
            return i;
        }

        public int update(int id,String name,String pwd,String email) throws SQLException {
            String sql="update admin set adminname=?,adminpwd=?,email=? where adminid=?";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                prem.setString(1,name);
                prem.setString(2,pwd);
                prem.setString(3,email);
                prem.setInt(4,id);
                i=prem.executeUpdate();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally {
                BaseDao.close(null,prem,con);
            }
            return i ;
        }

        public ArrayList findALL() throws SQLException {
            String sql="select * from announcement";
            try {
                con=BaseDao.getConnection();
                prem=con.prepareStatement(sql);
                rs=prem.executeQuery();
                while (rs.next()){
                    announcement t=new announcement();
                    t.setAnid(rs.getInt(1));
                    t.setAntitle(rs.getString(2));
                    t.setAndetail(rs.getString(3));
                    t.setDatetime(rs.getTime(4));
                    list.add(t);
                }
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }finally {
                BaseDao.close(rs,prem,con);
            }
            return list;
        }

    }

